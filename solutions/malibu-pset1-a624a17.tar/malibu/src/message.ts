import { Literal, Record, String, Array, Union, Static } from 'runtypes'

export const HelloMessage = Record({
  type: Literal('hello'),
  version: String,
  agent: String
})
export type HelloMessageType = Static<typeof HelloMessage>

export const GetPeersMessage = Record({
  type: Literal('getpeers')
})
export type GetPeersMessageType = Static<typeof GetPeersMessage>

export const PeersMessage = Record({
  type: Literal('peers'),
  peers: Array(String)
})
export type PeersMessageType = Static<typeof PeersMessage>

export const ErrorMessage = Record({
  type: Literal('error'),
  error: String
})
export type ErrorMessageType = Static<typeof ErrorMessage>

export const Message = Union(HelloMessage, GetPeersMessage, PeersMessage, ErrorMessage)
export type MessageType = Static<typeof Message>

export const Messages = [HelloMessage, GetPeersMessage, PeersMessage, ErrorMessage]
