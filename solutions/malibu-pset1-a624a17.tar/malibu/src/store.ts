import level from 'level-ts'

export const db = new level('./db')
