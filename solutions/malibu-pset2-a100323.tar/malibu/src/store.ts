export type ObjectId = string

import level from 'level-ts'
import sha256 from 'fast-sha256'
import { canonicalize } from 'json-canonicalize'
import { TransactionObject, ObjectType } from './message'
import { Transaction } from './transaction'
import { logger } from './logger'

export const db = new level('./db')

export class ObjectStorage {
  static id(obj: any) {
    const encoder = new TextEncoder()
    const objStr = canonicalize(obj)
    const hash = sha256(encoder.encode(objStr))
    const hashHex = Buffer.from(hash).toString('hex')

    return hashHex
  }
  static async exists(objectid: ObjectId) {
    return await db.exists(`object:${objectid}`)
  }
  static async get(objectid: ObjectId) {
    return await db.get(`object:${objectid}`)
  }
  static async del(objectid: ObjectId) {
    return await db.del(`object:${objectid}`)
  }
  static async put(object: any) {
    logger.debug(`Storing object with id ${this.id(object)}: %o`, object)
    return await db.put(`object:${this.id(object)}`, object)
  }
  static async validate(object: ObjectType) {
    if (!TransactionObject.guard(object)) {
      return
    }
    const tx = Transaction.fromNetworkObject(object)
    await tx.validate()
  }
}
